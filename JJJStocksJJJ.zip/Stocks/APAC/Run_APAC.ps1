param([switch]$Test)
$ErrorActionPreference = "Stop"

# Folder of this script (…\Stocks\APAC)
$Here = $PSScriptRoot
if (-not $Here) {
  # Fallback for older hosts: works in script context
  $Here = Split-Path -Path $MyInvocation.MyCommand.Path -Parent
}

# Project root = parent of APAC (…\Stocks)
$Root    = Split-Path -Path $Here -Parent
$Scanner = Join-Path $Root "core\smart_scan.py"

if (!(Test-Path -LiteralPath $Scanner)) {
  throw "Missing scanner: $Scanner`nExpected at: $Root\core\smart_scan.py"
}

$Python = "python"
$Args   = @("--region","apac")
if ($Test) { $Args += "--test" }

Write-Host "Running: $Python `"$Scanner`" $($Args -join ' ')"
& $Python $Scanner @Args
exit $LASTEXITCODE
