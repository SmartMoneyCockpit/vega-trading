﻿param([switch]$SyncOnly)

$ErrorActionPreference = "Stop"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

$pythonExe = Join-Path $env:LOCALAPPDATA "Programs\Python\Python310\python.exe"
if (-not (Test-Path $pythonExe)) {
    Write-Host "Python 3.10 not found, using py -3 launcher..."
    $pythonExe = "py"
    $pyArgs = @("-3")
} else {
    $pyArgs = @()
}

$scanner = Join-Path $here "smart_scan.py"
$rawList = Join-Path $here "RawList.txt"
$outdir  = Join-Path $here "outputs"
New-Item -ItemType Directory -Force -Path $outdir | Out-Null

if (-not $SyncOnly) {
    Write-Host "🚀 Starting Canada scan…"
    & $pythonExe @pyArgs $scanner --region CA --rawlist $rawList --outdir $outdir
} else {
    Write-Host "🔁 SyncOnly: skipping scan, using latest files in '$outdir'..."
}

$latestLong  = Get-ChildItem $outdir -Filter "scored_long_CA_*.csv"  | Sort-Object LastWriteTime -Descending | Select-Object -First 1
$latestShort = Get-ChildItem $outdir -Filter "scored_short_CA_*.csv" | Sort-Object LastWriteTime -Descending | Select-Object -First 1

if ($latestLong -and $latestShort) {
    Copy-Item $latestLong.FullName  (Join-Path $here "results_LONG.csv")  -Force
    Copy-Item $latestShort.FullName (Join-Path $here "results_SHORT.csv") -Force
    Write-Host "✅ Ready — results_LONG.csv and results_SHORT.csv refreshed."
} else {
    Write-Host "⚠️ Could not find scored_long_CA_* or scored_short_CA_* in '$outdir'."
}
