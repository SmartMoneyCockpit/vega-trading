# Run_LATAM.ps1 — LATAM screener (ex-Mexico)
$ErrorActionPreference = "Stop"

$ROOT = "C:\Users\dares\Desktop\Stocks"
$REGION_DIR = Join-Path $ROOT "LATHAM"   # use your actual folder name
$RAW = Join-Path $REGION_DIR "RawList.txt"

# Optional: merged outputs across runs
# $env:FINAL_LONG_PATH  = Join-Path $REGION_DIR "out\final_long_LATAM.csv"
# $env:FINAL_SHORT_PATH = Join-Path $REGION_DIR "out\final_short_LATAM.csv"

Set-Location $REGION_DIR
python (Join-Path $ROOT "smart_scan.py") `
  --region LATAM `
  --raw "$RAW" `
  --min-price 3 `
  --min-avgvol30 30000 `
  --min-dollarvol30 500000
