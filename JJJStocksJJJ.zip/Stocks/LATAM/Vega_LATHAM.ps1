# Vega_LATHAM.ps1 — Latin America scan (both sides) — ASCII-clean

$ErrorActionPreference = 'Stop'

# 1) Enter script dir
$root = $PSScriptRoot; if (-not $root) { $root = (Get-Location).Path }
Set-Location -LiteralPath $root
try { Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -ErrorAction Stop } catch {}

# 2) Load .env (EODHD_API_TOKEN)
$envPath = Join-Path $root ".env"
if (Test-Path $envPath) {
  foreach ($l in Get-Content $envPath) {
    if ($l -match '^\s*EODHD_API_TOKEN\s*=\s*(.+)\s*$') {
      $env:EODHD_API_TOKEN = $matches[1].Trim('"').Trim("'")
      break
    }
  }
}

# 3) Prompt for token if missing
if (-not $env:EODHD_API_TOKEN) {
  $secure = Read-Host "Enter EODHD API token (input hidden)" -AsSecureString
  $env:EODHD_API_TOKEN = [Runtime.InteropServices.Marshal]::PtrToStringAuto(
    [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
  )
}

# 4) Token sanity check (use US symbol to avoid entitlement 401s)
try {
  $testUrl = "https://eodhd.com/api/eod/AAPL.US?from=2024-10-01&to=2024-10-05&api_token=$($env:EODHD_API_TOKEN)&fmt=json"
  $resp = Invoke-WebRequest -UseBasicParsing -Uri $testUrl -TimeoutSec 15 -ErrorAction Stop
  if ($resp.StatusCode -eq 200) {
    Write-Host "OK: token check passed." -ForegroundColor Green
  } else {
    Write-Host "WARN: token check HTTP $($resp.StatusCode)" -ForegroundColor Yellow
  }
} catch {
  Write-Host ("WARN: token check skipped: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}

# 5) Fixed params: LATHAM + both
$Region = "LATHAM"
$Side   = "both"
$PyExe  = "python"  # change to full path if needed

Write-Host ("Running Smart Scan (Region={0}, Side={1})..." -f $Region,$Side) -ForegroundColor Cyan

# 6) Launch Python screener
$argsList = @(
  "smart_scan_lean.py",
  "--region", $Region,
  "--side",   $Side,
  "--tickers", "tickers_master.csv",
  "--aliases", "symbol_aliases.json",
  "--no-earnings-30d",
  "--vv-score"
)
$proc = Start-Process -FilePath $PyExe -ArgumentList $argsList -NoNewWindow -PassThru
$proc.WaitForExit()
$code = $proc.ExitCode

# 7) Open newest output folder and CSVs
try {
  $latest = Get-ChildItem -Directory -Filter "output_*_LEAN" |
            Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($latest) {
    $long  = Join-Path $latest.FullName "results_long.csv"
    $short = Join-Path $latest.FullName "results_short.csv"
    if (Test-Path $long)  { Invoke-Item $long }
    if (Test-Path $short) { Invoke-Item $short }
    Start-Process explorer.exe $latest.FullName
  } else {
    Write-Host "INFO: No output_*_LEAN folder found." -ForegroundColor Yellow
  }
} catch {
  Write-Host ("INFO: Could not auto-open results: {0}" -f $_.Exception.Message) -ForegroundColor Yellow
}

exit $code
