﻿param([switch]$SyncOnly)

$ErrorActionPreference = "Stop"

# Work from this folder
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

# Python resolver (py -3 fallback)
$pythonExe = Join-Path $env:LOCALAPPDATA "Programs\Python\Python310\python.exe"
if (-not (Test-Path $pythonExe)) { $pythonExe = "py"; $pyArgs = @("-3") } else { $pyArgs = @() }

# Scanner path (your core scanner)
$scanner = "C:\Users\dares\Desktop\Stocks\core\smart_scan.py"
if (-not (Test-Path $scanner)) { throw "Missing scanner: $scanner" }

# Run the scan (smart_scan.py does NOT take --rawlist/--outdir)
if (-not $SyncOnly) {
    Write-Host "Starting USA scan..."
    & $pythonExe @pyArgs $scanner `
        --region US `
        --min-price 5 `
        --min-avgvol30 100000 `
        --min-dollarvol30 2000000 `
        --auto-suffix
} else {
    Write-Host "SyncOnly: skipping scan."
}

# Find newest timestamped results anywhere under this USA folder
$latestLong  = Get-ChildItem $here -Recurse -File -Include "scored_long_US_*.csv","scored_long_*US*.csv","scored_long_*.csv"  |
               Sort-Object LastWriteTime -Descending | Select-Object -First 1
$latestShort = Get-ChildItem $here -Recurse -File -Include "scored_short_US_*.csv","scored_short_*US*.csv","scored_short_*.csv" |
               Sort-Object LastWriteTime -Descending | Select-Object -First 1

if ($latestLong -and $latestShort) {
    Copy-Item $latestLong.FullName  (Join-Path $here "results_LONG.csv")  -Force
    Copy-Item $latestShort.FullName (Join-Path $here "results_SHORT.csv") -Force
    Write-Host "USA ready — results_LONG.csv and results_SHORT.csv refreshed."
} else {
    Write-Host "USA: could not find scored_long_US_* or scored_short_US_* under $here."
}
