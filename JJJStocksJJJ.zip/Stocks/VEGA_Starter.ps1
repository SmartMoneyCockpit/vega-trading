param(
  [ValidateSet("ALL","USA","CANADA","LATHAM")] [string]$Region = "ALL",
  [ValidateSet("both","long","short")] [string]$Side   = "both"
)

# Enter script dir
$root = $PSScriptRoot; if (-not $root) { $root = (Get-Location).Path }
Set-Location -LiteralPath $root

try { Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -ErrorAction Stop } catch {}

# Load .env if present
$envPath = Join-Path (Get-Location) ".env"
if (Test-Path -LiteralPath $envPath) {
  $line = (Get-Content -LiteralPath $envPath | Where-Object { $_ -match '^\s*EODHD_API_TOKEN\s*=' } | Select-Object -First 1)
  if ($line) {
    $val = ($line -split '=',2)[1].Trim().Trim('"').Trim("'")
    if ($val) { $env:EODHD_API_TOKEN = $val }
  }
}

# Validate token
if (-not $env:EODHD_API_TOKEN) {
  $secure = Read-Host "Enter EODHD API token (input hidden)" -AsSecureString
  $plain  = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure))
  $env:EODHD_API_TOKEN = $plain
}
try {
  $url = "https://eodhd.com/api/eod/WALMEX.MX?from=2024-10-01&to=2025-10-25&api_token=$($env:EODHD_API_TOKEN)&fmt=json"
  $status = (Invoke-WebRequest -UseBasicParsing -Uri $url -TimeoutSec 20).StatusCode
  if ($status -eq 200) { Write-Host "✓ EODHD token validated (HTTP 200)." -ForegroundColor Green }
  else { Write-Host "⚠ Token validation returned HTTP $status — continuing." -ForegroundColor Yellow }
} catch { Write-Host "⚠ Token validation skipped: $($_.Exception.Message)" -ForegroundColor Yellow }

# Prompt to open results later
$open = Read-Host "Open results after run? (Y/N)"

# Run Python
$py = "python"
$stamp = (Get-Date -Format 'yyyyMMdd_HHmmss')
Write-Host "▶ Running lean screener..." -ForegroundColor Cyan
& $py "smart_scan_lean.py" --region $Region --side $Side --tickers "tickers_master.csv" --aliases "symbol_aliases.json" --no-earnings-30d --vv-score
$code = $LASTEXITCODE

# Post-process: merge to Excel + JSON
try {
  # Find freshest output_*_LEAN
  $latest = Get-ChildItem -Directory -Filter "output_*_LEAN" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if ($latest) {
    # Simple Excel build using PowerShell Import/Export-CSV alternately we could rely on Python, but keep minimal deps
    # We'll just open CSVs; Excel will open them. For JSON summary we skip for lean pack to reduce deps.
    if ($open -match '^[Yy]') {
      $long = Join-Path $latest.FullName "results_long.csv"
      $short= Join-Path $latest.FullName "results_short.csv"
      if (Test-Path $long) { Invoke-Item $long }
      if (Test-Path $short){ Invoke-Item $short }
      Start-Process explorer.exe $latest.FullName
    }
  }
} catch {}

exit $code
