# smart_scan.py — Multi-Region Stock Screener (Daily EOD)
# Technical + Fundamental + Ruler + EMA Squeeze + Traffic Light grading
# Regions: CA (Canada), US (United States), MX (Mexico), LATAM (Latin America), APAC (Asia-Pacific)
# Uses 30-day average volume filters and composite grading.
# Hardened for: BOM/odd chars, class shares (BRK.B→BRK-B), yfinance multi-index, 1-D coercion.
# Stability guards on indicator lengths (MACD/RSI/EMA/ADX/Breakout)

import os, csv, time, pathlib, math, warnings, json, hashlib, logging
from typing import List, Literal, Dict, Any, Tuple
import pandas as pd
import numpy as np
import yfinance as yf
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone   # ← add timezone
from pathlib import Path

# ── Quiet noisy libraries and pandas warnings ────────────────────────────────
logging.getLogger("yfinance").setLevel(logging.CRITICAL)
logging.getLogger("urllib3").setLevel(logging.ERROR)
pd.options.mode.chained_assignment = None
warnings.filterwarnings("ignore", category=FutureWarning)

# EXTRA: silence yfinance internal retry/console spam
try:
    yf.utils.get_yf_logger().setLevel(logging.CRITICAL)
except Exception:
    pass

# ──────────────────────────────────────────────────────────────────────────────
# REGION DEFAULTS (override via CLI flags)
# ──────────────────────────────────────────────────────────────────────────────
REGION_DEFAULTS = {
    "CA":    {"min_price": 5.0, "min_avgvol30": 50_000,  "min_dollarvol30": 1_500_000, "suffix": ".TO"},
    "US":    {"min_price": 5.0, "min_avgvol30": 100_000, "min_dollarvol30": 2_000_000, "suffix": ""},
    "MX":    {"min_price": 3.0, "min_avgvol30": 30_000,  "min_dollarvol30": 500_000,   "suffix": ".MX"},
    "LATAM": {"min_price": 3.0, "min_avgvol30": 30_000,  "min_dollarvol30": 500_000,   "suffix": ""},
    # APAC defaults (US-listed ETFs/ADRs and suffixed locals; no auto suffix)
    "APAC":  {"min_price": 5.0, "min_avgvol30": 100_000, "min_dollarvol30": 2_000_000, "suffix": ""},
}

# ── FINAL APPEND TARGETS (optional: merge across chunks via PS1) ──────────────
FINAL_LONG_PATH  = os.getenv("FINAL_LONG_PATH",  "").strip()
FINAL_SHORT_PATH = os.getenv("FINAL_SHORT_PATH", "").strip()

def _append_row(final_path: str, row: Dict[str, Any], header_order: List[str]):
    if not final_path:
        return
    p = pathlib.Path(final_path)
    p.parent.mkdir(parents=True, exist_ok=True)
    write_header = not p.exists()
    with open(p, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header_order, extrasaction="ignore")
        if write_header: w.writeheader()
        w.writerow(row)

# ── Throttle (CLI-overridable) ───────────────────────────────────────────────
MAX_THREADS = 6     # safe default; tune with --threads
DELAY_SEC   = 0.25  # tune with --delay
TIMEOUT_SEC = 60

# Quiet/progress globals (set after argparse)
QUIET_MODE = "fails"        # none|fails|passes|summary
PROGRESS_EVERY = 50         # heartbeat interval
CACHE_DIR = Path(os.getenv("SCAN_CACHE_DIR", "cache"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)
CACHE_TTL_HOURS = int(os.getenv("SCAN_CACHE_TTL_HOURS", "12"))

# ──────────────────────────────────────────────────────────────────────────────
# Technical thresholds
# ──────────────────────────────────────────────────────────────────────────────
SQUEEZE_PCT = 0.03
SLOPE_LOOKBACK = 3
ADX_LEN = 14
ADX_MIN = 20
BO_WINDOW = 20
VOLUME_THRUST = 1.3
ATR_MIN = 0.01
ATR_MAX = 0.06
PROX_52W_PCT = 0.15
GAP_MAX = 0.03

# Ruler
RULER_WIN = 100
RULER_MIN_R2 = 0.80
RULER_VOL14_MAX = 0.03
RULER_MAX_DRAWDOWN = 0.18
RULER_PCT_ABOVE_EMA50_LONG = 0.70
RULER_PCT_ABOVE_EMA50_SHORT = 0.30

# Fundamentals (Vega A-Z prelim style)
PE_MIN, PE_MAX = 5, 35
REV_GROWTH_MIN = 0.00
EPS_GROWTH_MIN = 0.00
PROFIT_MARGIN_MIN = 0.00
GROSS_MARGIN_MIN = 0.20
OPER_MARGIN_MIN = 0.10
ROE_MIN = 0.10
DEBT_TO_EQUITY_MAX = 2.0
CURRENT_RATIO_MIN = 1.0
EARNINGS_WINDOW_DAYS = 30  # skip if earnings within 30 days

# ──────────────────────────────────────────────────────────────────────────────
# Scoring bands
# ──────────────────────────────────────────────────────────────────────────────
def grade_from_score(score_total: int) -> Tuple[str, str]:
    if score_total >= 14: return "A+", "🟢"
    if score_total >= 12: return "A",  "🟢"
    if score_total >= 9:  return "B",  "🟡"
    if score_total >= 6:  return "C",  "🟠"
    return "D", "🔴"

failed, completed_count, total_count = [], 0, 0
start_time = datetime.now()

# ──────────────────────────────────────────────────────────────────────────────
# Normalization & 1-D coercion helpers (with region-aware suffixing)
# ──────────────────────────────────────────────────────────────────────────────
def normalize_ticker(raw: str, region: str, auto_suffix: bool) -> str:
    t = (raw or "").replace("\ufeff", "").strip().upper()
    t = t.replace("/", "-")  # class shares: BRK/B→BRK-B
    has_suffix = "." in t or t.endswith("-U") or t.endswith("-PR") or t.endswith("-WS")
    if auto_suffix:
        suf = REGION_DEFAULTS.get(region, {}).get("suffix", "")
        if suf and not has_suffix: t = f"{t}{suf}"
    return t

def _to_1d_series(x):
    if isinstance(x, pd.DataFrame): x = x.iloc[:, 0]
    elif not isinstance(x, pd.Series): x = pd.Series(x)
    return pd.to_numeric(x, errors="coerce")

def _enough(series_or_df, n: int) -> bool:
    if isinstance(series_or_df, pd.DataFrame):
        return int(series_or_df.dropna(how="all").shape[0]) >= n
    s = _to_1d_series(series_or_df).dropna()
    return len(s) >= n

# ──────────────────────────────────────────────────────────────────────────────
# Quiet printing / heartbeat helpers
# ──────────────────────────────────────────────────────────────────────────────
def _should_print_pass() -> bool:
    return QUIET_MODE in ("fails", "passes")

def _should_print_fail() -> bool:
    return QUIET_MODE in ("fails",)

def _progress_heartbeat() -> bool:
    return PROGRESS_EVERY > 0 and (completed_count % PROGRESS_EVERY == 0)

def _diag(symbol: str, side: str, category: str, reason: str, region: str):
    global completed_count
    completed_count += 1
    if QUIET_MODE == "summary":
        if _progress_heartbeat():
            pct = 100 * completed_count / max(1, total_count)
            print(f"[{region}] {side.upper():5} progress: {completed_count}/{total_count} ({pct:4.1f}%)")
        return
    if "FAIL" in category or "EARNINGS_WINDOW" in category or "NOT_QUALIFIED" in category:
        if not _should_print_fail(): return
    else:
        if not _should_print_pass(): return
    pct = 100 * completed_count / max(1, total_count)
    print(f"{symbol:<12} [{region:<6}] [{side.upper():5}] {category:<15} — {reason}   [{completed_count}/{total_count}] {pct:5.1f}%")

# ──────────────────────────────────────────────────────────────────────────────
# Utilities / indicators
# ──────────────────────────────────────────────────────────────────────────────
def ema(s, span: int) -> pd.Series:
    s = _to_1d_series(s)
    return s.ewm(span=span, adjust=False).mean()

def rsi(series, period=14):
    series = _to_1d_series(series)
    d = series.diff()
    gain = d.clip(lower=0).rolling(period).mean()
    loss = -d.clip(upper=0).rolling(period).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def macd(series, fast=12, slow=26, signal=9):
    series = _to_1d_series(series)
    macd_line = ema(series, fast) - ema(series, slow)
    signal_line = ema(macd_line, signal)
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

def slope(series, lookback=3):
    s = _to_1d_series(series).dropna()
    if len(s) < lookback + 1: return np.nan
    return float(s.iloc[-1] - s.iloc[-1 - lookback])

def true_range(h, l, c_prev):
    return np.maximum(h - l, np.maximum(abs(h - c_prev), abs(l - c_prev)))

def atr(df: pd.DataFrame, n=14):
    h = _to_1d_series(df["High"]); l = _to_1d_series(df["Low"]); c = _to_1d_series(df["Close"])
    tr = pd.Series(true_range(h.values, l.values, c.shift(1).values), index=df.index)
    return tr.rolling(n, min_periods=1).mean()

def di_adx(df: pd.DataFrame, n=14):
    h = _to_1d_series(df["High"]); l = _to_1d_series(df["Low"]); c = _to_1d_series(df["Close"])
    up, down = h.diff(), -l.diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    tr = np.maximum(h - l, np.maximum(abs(h - c.shift(1)), abs(l - c.shift(1))))
    atr_n = pd.Series(tr, index=df.index).rolling(n, min_periods=1).mean()
    plus_di = 100 * pd.Series(plus_dm, index=df.index).rolling(n, min_periods=1).mean() / atr_n
    minus_di = 100 * pd.Series(minus_dm, index=df.index).rolling(n, min_periods=1).mean() / atr_n
    dx = (100 * (abs(plus_di - minus_di) / (plus_di + minus_di))).replace([np.inf, -np.inf], np.nan)
    adx_ = dx.rolling(n, min_periods=1).mean()
    return plus_di, minus_di, adx_

# ──────────────────────────────────────────────────────────────────────────────
# Lightweight CSV cache to reduce repeat network calls
# ──────────────────────────────────────────────────────────────────────────────
def _cache_path(ticker: str) -> Path:
    key = hashlib.md5(ticker.encode("utf-8")).hexdigest()
    return CACHE_DIR / f"{key}_{ticker}.csv"

def _load_from_cache(ticker: str) -> pd.DataFrame:
    p = _cache_path(ticker)
    if not p.exists(): return pd.DataFrame()
    age_h = (datetime.now() - datetime.fromtimestamp(p.stat().st_mtime)).total_seconds() / 3600.0
    if age_h > CACHE_TTL_HOURS: return pd.DataFrame()
    try:
        df = pd.read_csv(p, parse_dates=True, index_col=0)
        df.columns = [str(c).title() for c in df.columns]
        need = ["Open","High","Low","Close","Volume"]
        if all(n in df.columns for n in need):
            return df.loc[:, need].dropna(how="all")
    except Exception:
        return pd.DataFrame()
    return pd.DataFrame()

def _save_to_cache(ticker: str, df: pd.DataFrame):
    try:
        _cache_path(ticker).write_text(df.to_csv())
    except Exception:
        pass

# ──────────────────────────────────────────────────────────────────────────────
# Data Fetch (robust with retries and fallbacks)
# ──────────────────────────────────────────────────────────────────────────────
def fetch_df(ticker: str) -> pd.DataFrame:
    """
    Robust Yahoo fetch with retries and three strategies:
      A) yf.download(period=1y, interval=1d)
      B) Ticker.history(period=1y, interval=1d)
      C) yf.download(start/end ~400d window)
    Normalizes columns and returns only Open/High/Low/Close/Volume.
    """
    # Cache first
    cdf = _load_from_cache(ticker)
    if not cdf.empty:
        return cdf

    def _normalize(df: pd.DataFrame) -> pd.DataFrame:
        if df is None or df.empty:
            return pd.DataFrame()
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[-1] if isinstance(c, tuple) else c for c in df.columns]
        df = df.rename(columns=str.title)
        need = ["Open","High","Low","Close","Volume"]
        if not all(n in df.columns for n in need):
            df.columns = [str(c).title() for c in df.columns]
        if not all(n in df.columns for n in need):
            return pd.DataFrame()
        df = df.loc[:, need].copy()
        df = df.loc[:, ~pd.Index(df.columns).duplicated(keep="first")]
        return df.dropna(how="all")

    def _sleep(i): time.sleep(DELAY_SEC * (1 + 0.75*i))

    # Attempt A: yf.download(period=1y)
    for i in range(2):
        try:
            df = yf.download(
                ticker, period="1y", interval="1d",
                auto_adjust=False, progress=False,
                timeout=TIMEOUT_SEC, threads=False, group_by="column"
            )
            df = _normalize(df)
            if not df.empty:
                _save_to_cache(ticker, df)
                return df
        except Exception:
            pass
        _sleep(i)

    # Attempt B: Ticker.history(period=1y)
    for i in range(2):
        try:
            t = yf.Ticker(ticker)
            df = t.history(period="1y", interval="1d", auto_adjust=False)
            df = _normalize(df)
            if not df.empty:
                _save_to_cache(ticker, df)
                return df
        except Exception:
            pass
        _sleep(i)

    # Attempt C: explicit 400-day window
    for i in range(2):
        try:
            end = datetime.now(timezone.utc).date()           # ← replace utcnow()
            start = end - pd.Timedelta(days=400)
            df = yf.download(
                ticker, start=str(start), end=str(end),
                interval="1d", auto_adjust=False,
                progress=False, timeout=TIMEOUT_SEC, threads=False, group_by="column"
            )
            df = _normalize(df)
            if not df.empty:
                _save_to_cache(ticker, df)
                return df
        except Exception:
            pass
        _sleep(i)

    return pd.DataFrame()

# ──────────────────────────────────────────────────────────────────────────────
# Fallback remaps for flaky local listings → ADR/ETF/OTC equivalents
# ──────────────────────────────────────────────────────────────────────────────
FALLBACK_REMAP: Dict[str, str] = {
    "AMXL.MX":     "AMX",    # América Móvil ADR
    "FEMSAUBD.MX": "FMX",    # FEMSA ADR
    "WALMEX.MX":   "WMMVY",  # Walmart de México ADR (OTC)
    "GMEXICOB.MX": "GMBXF",  # Grupo México (OTC)
    "CEMEXCPO.MX": "CX",     # Cemex ADR
    "PENOLES.MX":  "IPOAF",  # Industrias Peñoles (OTC)
    "SQM-B.SN":    "SQM",    # SQM ADR
    "LTM.SN":      "LTMAY",  # LATAM Airlines (OTC)
    # add more as needed
}

def fetch_df_any(ticker: str) -> pd.DataFrame:
    """Try original ticker; if empty and a remap exists, try the fallback."""
    df = fetch_df(ticker)
    if not df.empty:
        return df
    alt = FALLBACK_REMAP.get(ticker)
    if alt:
        dfa = fetch_df(alt)
        if not dfa.empty:
            dfa.attrs["alt_symbol"] = alt
            return dfa
    return df

# ──────────────────────────────────────────────────────────────────────────────
# Technical filters (with guards)
# ──────────────────────────────────────────────────────────────────────────────
def ema_squeeze(df):
    close = _to_1d_series(df["Close"]).dropna()
    if len(close) < 50:
        return False, False, float("nan"), pd.Series(dtype=float), pd.Series(dtype=float)
    e10, e20, e50 = ema(close,10), ema(close,20), ema(close,50)
    tight = abs(e10.iloc[-1]-e50.iloc[-1]) / close.iloc[-1]
    s10, s20, s50 = slope(e10, SLOPE_LOOKBACK), slope(e20, SLOPE_LOOKBACK), slope(e50, SLOPE_LOOKBACK)
    bull = e10.iloc[-1]>e20.iloc[-1]>e50.iloc[-1] and tight<=SQUEEZE_PCT and s10>0 and s20>0 and s50>0
    bear = e10.iloc[-1]<e20.iloc[-1]<e50.iloc[-1] and tight<=SQUEEZE_PCT and s10<0 and s20<0 and s50<0
    return bull, bear, tight, e20, e50

def breakout(df, side):
    c, v = _to_1d_series(df["Close"]).dropna(), _to_1d_series(df["Volume"]).dropna()
    if len(c) < max(2, BO_WINDOW) or len(v) < 2:
        return False
    hi_prev = c.rolling(BO_WINDOW, min_periods=1).max().iloc[-2]
    lo_prev = c.rolling(BO_WINDOW, min_periods=1).min().iloc[-2]
    avgv20 = v.rolling(20, min_periods=1).mean().iloc[-1]
    thrust = v.iloc[-1] >= VOLUME_THRUST * (avgv20 if not np.isnan(avgv20) else 0)
    return (c.iloc[-1] > hi_prev and thrust) if side=="long" else (c.iloc[-1] < lo_prev and thrust)

def ruler(df, side, e20, e50, e200):
    y = _to_1d_series(df["Close"]).dropna()
    if len(y) < RULER_WIN: return False, {}
    y = y.iloc[-RULER_WIN:]
    x = np.arange(len(y), dtype=float)
    slope_, inter = np.polyfit(x, y.values, 1)
    yhat = slope_ * x + inter
    ss_res = np.sum((y.values - yhat) ** 2)
    ss_tot = np.sum((y.values - np.mean(y.values) ) ** 2)
    r2 = 1 - (ss_res / ss_tot) if ss_tot != 0 else np.nan
    peaks = y.cummax()
    mdd = float(-((y - peaks) / peaks).min())
    vol14 = y.pct_change().dropna().iloc[-14:].std() if len(y) >= 15 else np.nan

    idx = df.index.intersection(e50.index)
    pct60 = np.nan
    if len(idx) >= 60:
        a = _to_1d_series(df["Close"].loc[idx].iloc[-60:])
        b = _to_1d_series(e50.loc[idx].iloc[-60:])
        pct60 = float((a > b).mean())

    if side == "long":
        ma_ok = e20.iloc[-1] > e50.iloc[-1] > e200.iloc[-1]; slope_ok = slope_ > 0
        pct_ok = (not np.isnan(pct60) and pct60 >= RULER_PCT_ABOVE_EMA50_LONG)
    else:
        ma_ok = e20.iloc[-1] < e50.iloc[-1] < e200.iloc[-1]; slope_ok = slope_ < 0
        pct_ok = (not np.isnan(pct60) and pct60 <= RULER_PCT_ABOVE_EMA50_SHORT)

    ok = (ma_ok and slope_ok and (not np.isnan(r2) and r2 >= RULER_MIN_R2) and
          (not np.isnan(mdd) and mdd <= RULER_MAX_DRAWDOWN) and
          (not np.isnan(vol14) and vol14 <= (RULER_VOL14_MAX if side=='long' else RULER_VOL14_MAX+0.005)) and
          pct_ok)

    return bool(ok), dict(LinR2=round(r2,4), MaxDD=round(mdd,4),
                          Vol14=round(vol14,4) if not np.isnan(vol14) else np.nan)

def prox_52w_ok(df, side):
    c = _to_1d_series(df["Close"]).dropna()
    if len(c) < 252: return False
    px = c.iloc[-1]
    hi = c.rolling(252, min_periods=1).max().iloc[-1]
    lo = c.rolling(252, min_periods=1).min().iloc[-1]
    return ((hi - px) / hi <= PROX_52W_PCT) if side=="long" else ((px - lo) / lo <= PROX_52W_PCT)

def gap_ok(df):
    if len(df) < 2: return True
    op = _to_1d_series(df["Open"]).iloc[-1]; prev = _to_1d_series(df["Close"]).iloc[-2]
    if np.isnan(op) or np.isnan(prev) or prev == 0: return True
    return abs(op - prev) / prev <= GAP_MAX

# ──────────────────────────────────────────────────────────────────────────────
# Fundamentals (via yfinance info + earnings window)
# ──────────────────────────────────────────────────────────────────────────────
def _get_info_safe(t: yf.Ticker) -> Dict[str, Any]:
    try:
        fn = getattr(t, "get_info", None)
        if fn:
            info = fn() or {}
            if isinstance(info, dict): return info
    except Exception:
        pass
    try:
        return dict(getattr(t, "info", {}) or {})
    except Exception:
        return {}

def fundamentals_score(ticker: str) -> Tuple[int, Dict[str, Any], bool]:
    try: t = yf.Ticker(ticker)
    except Exception: return 0, {}, True
    info = _get_info_safe(t)
    earnings_safe = True
    try:
        edf = t.get_earnings_dates(limit=4)
        if edf is not None and not edf.empty:
            dt = pd.Timestamp(edf.index[0]).to_pydatetime()
            delta = (dt - datetime.now()).days
            if 0 <= delta < EARNINGS_WINDOW_DAYS: earnings_safe = False
    except Exception:
        pass

    def g(key):
        try: return float(info.get(key, np.nan))
        except Exception: return np.nan

    pe = g("trailingPE"); rev = g("revenueGrowth"); eps = g("earningsQuarterlyGrowth")
    pm = g("profitMargins"); gm = g("grossMargins"); om = g("operatingMargins")
    roe = g("returnOnEquity"); d2e = g("debtToEquity"); cur = g("currentRatio")

    pts = 0
    if not np.isnan(pe) and PE_MIN <= pe <= PE_MAX: pts += 1
    if not np.isnan(rev) and rev > REV_GROWTH_MIN: pts += 1
    if not np.isnan(eps) and eps > EPS_GROWTH_MIN: pts += 1
    if not np.isnan(pm) and pm > PROFIT_MARGIN_MIN: pts += 1
    if not np.isnan(gm) and gm >= GROSS_MARGIN_MIN: pts += 1
    if not np.isnan(om) and om >= OPER_MARGIN_MIN: pts += 1
    if not np.isnan(roe) and roe >= ROE_MIN: pts += 1
    if not np.isnan(d2e) and d2e <= DEBT_TO_EQUITY_MAX: pts += 1
    if not np.isnan(cur) and cur >= CURRENT_RATIO_MIN: pts += 1

    detail = dict(trailingPE=pe, revenueGrowth=rev, earningsQuarterlyGrowth=eps,
                  profitMargins=pm, grossMargins=gm, operatingMargins=om,
                  returnOnEquity=roe, debtToEquity=d2e, currentRatio=cur)
    return pts, detail, earnings_safe

# ──────────────────────────────────────────────────────────────────────────────
# Universe loading (CSV or TXT)
# ──────────────────────────────────────────────────────────────────────────────
def _read_csv_symbols(path: Path) -> List[str]:
    df = pd.read_csv(path)
    for cand in ("symbol","ticker","sym"):
        hit = [c for c in df.columns if str(c).strip().lower() == cand]
        if hit:
            col = hit[0]
            syms = [str(s).strip().upper() for s in df[col].dropna().unique().tolist()]
            return syms
    raise ValueError(f"{path} must contain a 'symbol' (or 'ticker'/'sym') column")

def load_tickers_auto(region: str, raw_arg: str, auto_suffix: bool) -> List[str]:
    base = Path(__file__).resolve().parent.parent  # ...\Stocks
    uni_dir = base / "universes"
    txt_fallback = base / "RawList.txt"
    if raw_arg.upper() == "AUTO":
        csv_path = uni_dir / f"{region.lower()}.csv"
        if csv_path.exists():
            syms = _read_csv_symbols(csv_path)
            return [normalize_ticker(s, region, auto_suffix) for s in syms if s]
        if txt_fallback.exists():
            return load_tickers(str(txt_fallback), region, auto_suffix)
        if region == "APAC":
            seed = ["EWJ","EWA","EWH","EWT","EWY","EWS","MCHI","ASHR","EPI","TSM","TM","SONY","BHP","RIO"]
            return [normalize_ticker(s, region, auto_suffix) for s in seed]
        return []
    return load_tickers(raw_arg, region, auto_suffix)

def load_tickers(path: str, region: str, auto_suffix: bool) -> List[str]:
    p = Path(path)
    if not p.exists(): return []
    if p.suffix.lower() == ".csv":
        syms = _read_csv_symbols(p)
        return [normalize_ticker(s, region, auto_suffix) for s in syms if s]
    seen, out = set(), []
    with open(p, "r", encoding="utf-8-sig") as f:
        for line in f:
            tk = normalize_ticker(line, region, auto_suffix)
            if tk and tk not in seen:
                seen.add(tk); out.append(tk)
    return out

# ──────────────────────────────────────────────────────────────────────────────
# Scanner (side-aware) — with indicator length guards
# ──────────────────────────────────────────────────────────────────────────────
def scan_one(t: str, side: Literal["long","short"], region: str,
             MIN_PRICE: float, MIN_AVG_VOL30: int, MIN_DOLLAR_VOL30: int):
    df = fetch_df_any(t)   # ← use wrapper with ADR/ETF fallback
    if df.empty:
        failed.append(t); _diag(t, side, "DATA_FAIL", "No EOD data", region); return None

    close = _to_1d_series(df["Close"]).dropna()
    vol   = _to_1d_series(df["Volume"]).dropna()
    if close.empty:
        _diag(t, side, "DATA_FAIL", "No close series", region); return None
    if len(close) < 2 or len(vol) < 2:
        _diag(t, side, "DATA_FAIL", "Insufficient bars (price/volume)", region); return None

    price = float(close.iloc[-1])
    avgv30 = float(vol.rolling(30, min_periods=1).mean().iloc[-1])
    dollar30 = price * avgv30

    # Liquidity & price filters (30-day)
    if (price < MIN_PRICE) or (avgv30 < MIN_AVG_VOL30) or (dollar30 < MIN_DOLLAR_VOL30):
        _diag(t, side, "NOT_QUALIFIED",
              f"P={price:.2f}, V30={avgv30:.0f}, $30={dollar30:.0f}", region)
        return None

    # Enough bars for long EMAs
    if not _enough(close, 200):
        _diag(t, side, "DATA_FAIL", "Insufficient bars for EMA(200)", region); return None

    # Indicators (guarded)
    e20, e50, e200 = ema(close,20), ema(close,50), ema(close,200)
    macd_line, macd_sig, _ = macd(close)
    if _to_1d_series(macd_line).dropna().size < 2 or _to_1d_series(macd_sig).dropna().size < 2:
        _diag(t, side, "DATA_FAIL", "Insufficient MACD history", region); return None

    plus_di, minus_di, adx_ = di_adx(df, ADX_LEN)
    if _to_1d_series(adx_).dropna().size == 0:
        _diag(t, side, "DATA_FAIL", "Insufficient ADX history", region); return None

    atr_series = atr(df,14)
    atr_last = _to_1d_series(atr_series).dropna()
    if atr_last.size == 0:
        _diag(t, side, "DATA_FAIL", "Insufficient ATR history", region); return None
    atr_pct = float(atr_last.iloc[-1] / price) if price else np.nan

    bull_sq, bear_sq, tight, e20_sq, e50_sq = ema_squeeze(df)
    sq = bull_sq if side=="long" else bear_sq

    macd_bull = (macd_line.iloc[-2] <= macd_sig.iloc[-2]) and (macd_line.iloc[-1] > macd_sig.iloc[-1])
    macd_bear = (macd_line.iloc[-2] >= macd_sig.iloc[-2]) and (macd_line.iloc[-1] < macd_sig.iloc[-1])
    macd_hit = macd_bull if side=="long" else macd_bear

    r = rsi(close,14)
    if _to_1d_series(r).dropna().size < 2:
        _diag(t, side, "DATA_FAIL", "Insufficient RSI history", region); return None
    rsi_bull = (r.iloc[-2] < 50 <= r.iloc[-1]); rsi_bear = (r.iloc[-2] > 50 >= r.iloc[-1])
    rsi_hit = rsi_bull if side=="long" else rsi_bear

    sma_flag = (e50.iloc[-1] > e200.iloc[-1]) if side=="long" else (e50.iloc[-1] < e200.iloc[-1])
    adx_hit = (adx_.iloc[-1] >= ADX_MIN) and ((plus_di.iloc[-1] > minus_di.iloc[-1]) if side=="long" else (minus_di.iloc[-1] > plus_di.iloc[-1]))
    bo = breakout(df, side)
    atr_ok = (not np.isnan(atr_pct)) and (ATR_MIN <= atr_pct <= ATR_MAX)
    ruler_ok, ruler_metrics = ruler(df, side, e20, e50, e200)
    prox_ok = prox_52w_ok(df, side)
    gap_pass = gap_ok(df)

    # Tech score: 1 point each if true
    tech_pts = sum(int(x) for x in [sq, macd_hit, rsi_hit, sma_flag, adx_hit, bo, atr_ok, ruler_ok])

    # Fundamentals + earnings safety
    fund_pts, fund_detail, earnings_safe = fundamentals_score(t)
    if not earnings_safe:
        _diag(t, side, "EARNINGS_WINDOW", "Within 30d — skipped", region)
        return None

    total = int(tech_pts + fund_pts)
    grade, emoji = grade_from_score(total)

    # Console line (traffic light inline)
    signals = f"sq={int(sq)} macd={int(macd_hit)} rsi={int(rsi_hit)} bo={int(bo)} adx={int(adx_hit)} ruler={int(ruler_ok)}"
    _diag(t, side, f"PASS {grade}{emoji}", f"tech={tech_pts}/8 fund={fund_pts}/9 | {signals}", region)

    row = dict(
        Region=region, Symbol=t, Side=side, Price=round(price,2),
        AvgVol30=int(avgv30), DollarVol30=int(dollar30),
        Score_Tech=int(tech_pts), Score_Fund=int(fund_pts),
        Score_Total=total, Grade=grade, GradeEmoji=emoji,
        EMA_SQ=bool(sq), Tightness_10_50_Px=(round(tight,4) if isinstance(tight,(int,float)) and not math.isnan(tight) else np.nan),
        MACD=bool(macd_hit), RSI=bool(rsi_hit), SMA50v200=bool(sma_flag),
        ADX_OK=bool(adx_hit), ADX=(round(float(adx_.iloc[-1]),2) if not np.isnan(adx_.iloc[-1]) else np.nan),
        BO_or_BD=bool(bo), ATR_OK=bool(atr_ok), ATR14_pct=(round(atr_pct,4) if not np.isnan(atr_pct) else np.nan),
        RULER=bool(ruler_ok), **ruler_metrics,
        Prox52W_OK=bool(prox_ok), Gap_OK=bool(gap_pass),
        trailingPE=fund_detail.get("trailingPE"),
        revenueGrowth=fund_detail.get("revenueGrowth"),
        earningsQuarterlyGrowth=fund_detail.get("earningsQuarterlyGrowth"),
        profitMargins=fund_detail.get("profitMargins"),
        grossMargins=fund_detail.get("grossMargins"),
        operatingMargins=fund_detail.get("operatingMargins"),
        returnOnEquity=fund_detail.get("returnOnEquity"),
        debtToEquity=fund_detail.get("debtToEquity"),
        currentRatio=fund_detail.get("currentRatio"),
    )
    return row

# ──────────────────────────────────────────────────────────────────────────────
# Parallel
# ──────────────────────────────────────────────────────────────────────────────
def run_side(tickers: List[str], side: Literal["long","short"], region: str,
             MIN_PRICE: float, MIN_AVG_VOL30: int, MIN_DOLLAR_VOL30: int) -> pd.DataFrame:
    global completed_count, total_count, start_time
    completed_count = 0; total_count = len(tickers); start_time = datetime.now()
    results: List[Dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=MAX_THREADS) as ex:
        futs = [ex.submit(scan_one, t, side, region, MIN_PRICE, MIN_AVG_VOL30, MIN_DOLLAR_VOL30) for t in tickers]
        for fut in as_completed(futs):
            res = fut.result()
            if res:
                results.append(res)
                header = list(res.keys())
                if side == "long": _append_row(FINAL_LONG_PATH,  res, header)
                else:              _append_row(FINAL_SHORT_PATH, res, header)
            # NOTE: removed duplicate heartbeat here; _diag() handles summary printing
    return pd.DataFrame(results)

# ──────────────────────────────────────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────────────────────────────────────
if __name__=="__main__":
    import argparse
    ap = argparse.ArgumentParser(description="Multi-Region Screener (Tech + Fund + Traffic Light)")
    ap.add_argument("--region", choices=["CA","US","MX","LATAM","APAC"], required=True, help="Market region")
    ap.add_argument("--raw", default="AUTO", help="Path to ticker list (.csv 'symbol' header or .txt). AUTO = universes/<region>.csv or RawList.txt")
    ap.add_argument("--auto-suffix", action="store_true", help="Auto-append region suffix (.TO for CA, .MX for MX)")
    ap.add_argument("--min-price", type=float, default=None, help="Override region min price")
    ap.add_argument("--min-avgvol30", type=int, default=None, help="Override region min 30D average volume (shares)")
    ap.add_argument("--min-dollarvol30", type=int, default=None, help="Override region min 30D dollar volume (Price*Vol)")
    # New tunables
    ap.add_argument("--threads", type=int, default=MAX_THREADS, help="Worker threads (default 6)")
    ap.add_argument("--delay", type=float, default=DELAY_SEC, help="Delay between attempts (sec, default 0.25)")
    ap.add_argument("--quiet", choices=["none","fails","passes","summary"], default="fails",
                    help="Console output: none=fatal only, fails=errors+passes (default), passes=only pass lines, summary=heartbeats only")
    ap.add_argument("--progress-every", type=int, default=50, help="Print heartbeat every N tickers (summary mode)")
    ap.add_argument("--cache-ttl-h", type=int, default=CACHE_TTL_HOURS, help="CSV cache TTL hours (default 12)")
    args = ap.parse_args()

    # Apply runtime settings (no 'global' needed here)
    MAX_THREADS      = max(1, int(args.threads))
    DELAY_SEC        = max(0.05, float(args.delay))
    QUIET_MODE       = args.quiet
    PROGRESS_EVERY   = int(args.progress_every)
    CACHE_TTL_HOURS  = max(1, int(args.cache_ttl_h))

    # Region thresholds
    defaults = REGION_DEFAULTS[args.region]
    MIN_PRICE = args.min_price if args.min_price is not None else defaults["min_price"]
    MIN_AVG_VOL30 = args.min_avgvol30 if args.min_avgvol30 is not None else defaults["min_avgvol30"]
    MIN_DOLLAR_VOL30 = args.min_dollarvol30 if args.min_dollarvol30 is not None else defaults["min_dollarvol30"]

    # Load universe
    tickers = load_tickers_auto(args.region, args.raw, args.auto_suffix)
    print(f"🔍 [{args.region}] Loaded {len(tickers)} tickers (raw='{args.raw}')")
    print(f"   Thresholds: min_price={MIN_PRICE}, min_avgvol30={MIN_AVG_VOL30}, min_dollarvol30={MIN_DOLLAR_VOL30}")
    ts = time.strftime("%Y%m%d_%H%M%S")

    # LONG then SHORT
    print("🚀 LONG scan…")
    longdf = run_side(tickers, "long", args.region, MIN_PRICE, MIN_AVG_VOL30, MIN_DOLLAR_VOL30)
    print("📉 SHORT scan…")
    shortdf = run_side(tickers, "short", args.region, MIN_PRICE, MIN_AVG_VOL30, MIN_DOLLAR_VOL30)

    def _sort(df: pd.DataFrame):
        if df.empty: return df
        return df.sort_values(
            by=["Score_Total","DollarVol30","Price"],
            ascending=[False,False,False]
        ).reset_index(drop=True)

    longdf = _sort(longdf)
    shortdf = _sort(shortdf)

    # Region-tagged outputs to avoid overwrites across markets
    longfp  = f"scored_long_{args.region}_{ts}.csv"
    shortfp = f"scored_short_{args.region}_{ts}.csv"
    longdf.to_csv(longfp, index=False)
    shortdf.to_csv(shortfp, index=False)

    if failed:
        pd.DataFrame({"Failed": failed}).to_csv(f"failed_tickers_{args.region}_{ts}.csv", index=False)

    print(f"✅ Done — screener complete. Files: {longfp}  /  {shortfp}")

