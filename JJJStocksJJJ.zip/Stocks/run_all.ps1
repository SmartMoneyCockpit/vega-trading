
# Run all regions sequentially
$root = if ($PSScriptRoot -and $PSScriptRoot -ne "") { $PSScriptRoot } else { (Get-Location).Path }

& (Join-Path $root "Canada\Run_Canada.ps1")
& (Join-Path $root "USA\Run_USA.ps1")
& (Join-Path $root "LATHAM\Run_LATHAM.ps1")
